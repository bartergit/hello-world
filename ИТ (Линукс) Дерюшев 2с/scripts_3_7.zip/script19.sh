#!/bin/bash

read char
numbers='^[0-9]+$'
if [[ $char =~ $numbers ]] ; then
echo "Number"
elif [[ $char == [A-Z] ]] || [[ $char == [a-z] ]] ;
then
    echo "Letter"
else
    echo "Special symbol"
fi

