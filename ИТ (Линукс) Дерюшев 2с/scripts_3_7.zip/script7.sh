#!/bin/bash

count=0
sum=0
for i in $@
do 
	sum=` expr $sum + $i`
	count=` expr $count + 1`
done
if test $count -ne 3; then
	echo 'Try again'
else
	echo 'Average: '
	echo "scale=5; $sum / $count" | bc
fi
