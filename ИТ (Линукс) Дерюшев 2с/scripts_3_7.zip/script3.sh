#!/bin/bash

a=2;

a=`expr $a + 2 `;
echo $a;

a=`expr $a - 10`;
echo $a;

a=`expr $a "*" 3`;
echo $a;

a=`expr $a "/" 2`;
echo $a;