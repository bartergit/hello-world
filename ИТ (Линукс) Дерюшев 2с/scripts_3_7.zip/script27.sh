#!/bin/bash

for dir in Test/*; do
    if test -f $dir ; then
        echo There is wrong file 
        exit
    fi
done

echo Everything is fine