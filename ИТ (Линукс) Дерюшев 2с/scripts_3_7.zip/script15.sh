#!/bin/bash

echo "Enter three sides of triangle"
read a b c
if test "$a" -eq "$b" && test "$a" -eq "$c"; then
  echo "Triangle is equilateral"
else
  if test "$a" -eq "$b" || test "$b" -eq "$c" || test "$a" -eq "$c"; then
    echo "Triangle is isosceles"
  else
    if test "$((a*a))" -eq "$((b*b+c*c))" || test "$((b*b))" -eq "$((a*a+c*c))" || test "$((c*c))" -eq "$((b*b+a*a))"; then
      echo "Triangle is right"
    else
      echo "Sorry, i don't know what triangle is this"
    fi
  fi
fi