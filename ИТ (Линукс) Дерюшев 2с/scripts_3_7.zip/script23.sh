#!/bin/bash
read a

if test $a -eq 1; then 
	echo 'Not simple or composite'
fi

i=2
while test $i -lt $a
do
	if test `expr $a % $i` -eq 0; then
		echo "composite"
		break
	fi
i=`expr $i + 1`
done
if test $i -eq $a; then
	echo "simple"
fi