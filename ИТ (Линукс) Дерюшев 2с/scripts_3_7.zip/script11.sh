#!/bin/bash

if test $# -eq 2; then
    if test $1 -gt $2; then
        echo $1 greater;
    else
        echo $2 greater;
    fi
elif test $# -eq 3; then
    if test $1 -gt $2 && test $1 -gt $3; then
        echo $1 greater;
    elif test $2 -gt $1 && test $2 -gt $3; then
        echo $2 greater;
    elif test $2 -eq $1 && test $1 -eq $3; then
        echo All arguments are equal;
    else
        echo $3 greater;
    fi
else
    echo Not enough arguments;
fi
