#!/bin/bash
echo "Enter coordinates of the point:"
read x y
if test $x -gt 0 && test $y -gt 0
then
	echo "Your point in 1-st quadrant"
fi
if test $x -lt 0 && test $y -gt 0
then
	echo "Your point in 2-st quadrant"
fi
if test $x -lt 0 && test $y -lt 0
then
	echo "Your point in 3-st quadrant"
fi
if test $x -gt 0 && test $y -lt 0
then
	echo "Your point in 4-st quadrant"
fi
if test $x -eq 0 && test $y -eq 0
then
	echo "Your point in center"
fi
if test $x -eq 0 && test $y -ne 0
then
	echo "Your point on the x-axis"
fi
if test $x -ne 0 && test $y -eq 0
then
	echo "Your point on the y-axis"
fi