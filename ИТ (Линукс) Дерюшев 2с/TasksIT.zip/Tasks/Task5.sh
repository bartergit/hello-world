#!/bin/bash
echo 'Input system'
read in
echo 'Output system'
read out
echo 'Number'
read num
echo "obase=$out;ibase=$in;$num" | bc 