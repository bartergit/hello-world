#!/bin/bash
echo "Oh hi Mark"
echo "End Status: $?"
lsld
echo "End Status: $?"