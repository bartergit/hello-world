#!/bin/bash
echo 'Enter an expression with spaces between symbols:'
read a op b
case $op in
+)echo `expr $a + $b`;;
-)echo `expr $a - $b`;;
"*")echo `expr $a "*" $b`;;
/)echo  "scale=3; $a / $b" | bc;;
*)echo "I don't know what this operation is"
esac