#!/bin/bash
echo "Enter n"
read n
sum=0
i=1
while test $i -le $n
do
	sum=` expr $sum + $i`
	i=` expr $i + 1`
done
echo "scale=5; $sum / $n" | bc