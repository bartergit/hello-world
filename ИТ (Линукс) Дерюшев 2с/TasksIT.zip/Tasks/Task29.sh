#!/bin/bash
sumnum(){
local num=$1
local sum=$2
if test `expr $num / 10` -gt 0
then
	sum=`expr $sum + $num % 10`
	num=`expr $num / 10`
	sumnum  $num $sum
	return $?
else
	sum=`expr $sum + $num`
	return $sum
fi
}
read number
sum=0
sumnum $number $sum
echo $?

