#!/bin/bash
prev2=0
prev=0
cur=1
echo "Enter the last fibonacci number"
read n
while test $cur -lt $n
do
	printf $cur
	printf ', '
	prev2=$prev
	prev=$cur
	cur=`expr $prev + $prev2`
done
printf $cur
echo