#!/bin/bash
echo "input height"
read N
i=1
while [ $i -le $N ]
do
j=0
while [ $j -lt `expr "(" 20 "-" $i ")" "*" 2` ]
do
echo -n " "
j=$(($j+1))
done
j=0
l=$i
n=1
while [ $j -lt $i ]
do
echo -n $n " "
j=$(($j+1))
l=$(($l-1))
n=`expr $n "*" $l "/" $j`
done
i=$(($i+1))
echo ""
done
