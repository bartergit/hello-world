#!/bin/bash
echo "Enter the number"
read N
N=`expr $N % 2`
if [ $N -eq 1 ]
then 
echo "number is odd"
else 
echo "number is even"
fi
