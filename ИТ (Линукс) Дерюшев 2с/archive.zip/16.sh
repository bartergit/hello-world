#!/bin/bash
echo Введите день недели цифрой:
read day

if [ "$day" -eq 1 ] 
then
echo Понедельник
fi

if [ "$day" -eq 2 ] 
then
echo Вторник
fi

if [ "$day" -eq 3 ] 
then
echo Среда
fi

if [ "$day" -eq 4 ] 
then
echo Четверг
fi

if [ "$day" -eq 5 ] 
then
echo Пятница
fi

if [ "$day" -eq 6 ] 
then
echo Суббота
fi

if [ "$day" -eq 7 ] 
then
echo Воскресенье
fi

if [ "$day" -lt 1 ] || [ "$day" -gt 7 ] 
then
echo Не день недели
fi