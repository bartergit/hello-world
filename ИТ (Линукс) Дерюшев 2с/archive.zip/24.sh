#! /bin/bash

echo Первое число:
read n1
echo Второе число:
read n2

remainder=1
a=$n1
b=$n2
 
if [ $n2 -eq 0 ]
 then
  echo "GCD $n1"
 exit
fi
 
while [ $remainder -ne 0 ]
do
 remainder=`expr $n1 % $n2`
 n1=$n2
 n2=$remainder
done
 
echo "НОД: $n1"