#!/bin/bash
echo "Enter 1st number"
read n
echo "Enter second number"
read x
echo -n "multy "
echo "scale=3; $n*$x" | bc
echo -n "div "
echo "scale=3; $n/$x" | bc
echo -n "add "
echo "scale=3; $n+$x" | bc
echo -n "sub "
echo "scale=3; $n-$x" | bc

