#!/bin/bash
echo "What do u want. Enter 1, 2 or 3"
echo "1. Find the number of files and directories in the current location"
echo "2. Print 10 consecutive lines in this file"
echo "3. List of all processes owned by the current user"
read n
while [[ $n -ne 1 && $n -ne 2 && $n -ne 3 ]]
do
echo "Enter 1, 2 or 3"
read n
done
if [ $n -eq 1 ]
then 
x=$(ls -f . | wc -l)
echo "There are " $(($x-2)) " items"
ls -f .
elif [ $n -eq 2 ]
then
echo "Input file name"
read filename
echo "input string"
read string
n=0
while [ $n -lt 20 ]
do 
echo $string >> $filename
n=$(($n+1))
done
else 
ps -a
fi

