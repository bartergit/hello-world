#!/bin/bash

echo Первое число:
read arg_1
echo Второе число:
read arg_2

if [ "$arg_1" -gt "$arg_2" ]
then
  echo "$arg_1 > $arg_2"
else if [ "$arg_1" -lt "$arg_2" ]
then
  echo "$arg_1 < $arg_2"
else
  echo "$arg_1 = $arg_2" 
fi
fi