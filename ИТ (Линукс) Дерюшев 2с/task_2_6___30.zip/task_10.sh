#!/bin/bash
kill $1
