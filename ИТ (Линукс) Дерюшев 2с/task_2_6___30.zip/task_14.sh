#!/bin/bash
if [[ $(($1 % 4)) != 0 ]]
	then
	echo Usual year
	exit
fi
if [[ $(($1 % 100)) == 0 && $(($1 % 400)) !=  0 ]]
	then 
	echo Usual year
	exit
	else
	echo Leap year
fi

