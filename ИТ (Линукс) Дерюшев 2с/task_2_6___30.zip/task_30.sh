#! /bin/bash
remainder=1
a=$1
b=$2
if [[ $b = 0 || $a = 0 ]]
 then
  echo Enter natural value
 exit
fi
while [ $remainder -ne 0 ]
do
 remainder=`expr $a % $b`
 a=$b
 b=$remainder
done
echo LCM is $(($1*$2/$a))
