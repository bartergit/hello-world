#!/bin/bash
for i do
	sum=`expr $sum + $i`
done
echo Sum of arguments is $sum
echo Amount of arguments is $#
