#!/bin/bash
cal 05 2019
echo some of thing >> tempfile
echo something >> tempfile
grep 'of' ./tempfile
rm tempfile
