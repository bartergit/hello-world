#!/bin/bash
n=1
sum=0
fact=1
x=1
while [[ $n < $2 ]]
do
	sum=$(($sum + $x/$fact  ))
	x=$(($x*$1))
	fact=$(($fact*$n))
	n=$(($n+1))
done
echo Sum is $sum
