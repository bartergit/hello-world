#!/bin/bash
num=$1
while [ $num -gt 0 ]
	do
	sum=$(($sum + $num%10))
	num=$(($num/10))
done
echo Sum of digits of number $1 is $sum
